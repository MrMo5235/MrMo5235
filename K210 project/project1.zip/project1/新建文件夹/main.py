import sensor, image, lcd, time
import KPU as kpu
from machine import UART, Timer, PWM
import gc, sys, utime
from fpioa_manager import fm
from Maix import GPIO

input_size = (224, 224)
labels = ['Car license']
anchors = [6.5, 2.0, 6.5, 2.0, 6.5, 2.0, 6.5, 2.0, 6.5, 2.0]

def Servo():
    io_servo_pin = 22
    tim = Timer(Timer.TIMER0, Timer.CHANNEL0, mode=Timer.MODE_PWM)
    S1 = PWM(tim, freq=50, duty=0, pin=io_servo_pin)
    def Servo(angle):
        S1.duty(angle / 180 * 10 + 2.5)

    while (1):
        for i in range(0, 90, 1):
            Servo(i)
            utime.sleep_ms(20)
        utime.sleep_ms(2000)
        for i in range(90, 0, -1):
            Servo(i)
            utime.sleep_ms(20)
        break

def lcd_show_except(e):
    import uio
    err_str = uio.StringIO()
    sys.print_exception(e, err_str)
    err_str = err_str.getvalue()
    img = image.Image(size=input_size)
    img.draw_string(0, 10, err_str, scale=1, color=(0xff,0x00,0x00))
    lcd.display(img)

class Comm:
    def __init__(self, uart):
        self.uart = uart

    def send_detect_result(self, objects, labels):
        msg = ""
        for obj in objects:
            pos = obj.rect()
            p = obj.value()
            idx = obj.classid()
            label = labels[idx]
            msg += "{}:{}:{}:{}:{}:{:.2f}:{}, ".format(pos[0], pos[1], pos[2], pos[3], idx, p, label)
        if msg:
            msg = msg[:-2] + "\n"
        self.uart.write(msg.encode())

def init_uart():
    fm.register(10, fm.fpioa.UART1_TX, force=True)
    fm.register(11, fm.fpioa.UART1_RX, force=True)

    uart = UART(UART.UART1, 115200, 8, 0, 0, timeout=1000, read_buf_len=256)
    return uart

def main(anchors, labels = None, model_addr="/sd/model-149484.kmodel", sensor_window=input_size, lcd_rotation=1, sensor_hmirror=False, sensor_vflip=False):
    sensor.reset()
    sensor.reset()
    sensor.set_pixformat(sensor.RGB565)
    sensor.set_framesize(sensor.QVGA)
    sensor.set_auto_exposure(0)
    sensor.set_auto_gain(0, gain_db = 16)
    sensor.set_auto_whitebal(0)
    sensor.set_vflip(False)
    sensor.set_hmirror(False)
    sensor.set_windowing((224,224))
    sensor.skip_frames(time = 2000)
    sensor.run(1)


    lcd.init(type=1)
    lcd.rotation(lcd_rotation)
    lcd.clear(lcd.WHITE)

    if not labels:
        with open('labels.txt','r') as f:
            exec(f.read())
    if not labels:
        print("no labels.txt")
        img = image.Image(size=(320, 240))
        img.draw_string(90, 110, "no labels.txt", color=(255, 0, 0), scale=2)
        lcd.display(img)
        return 1
    try:
        img = image.Image("startup.jpg")
        lcd.display(img)
    except Exception:
        img = image.Image(size=(320, 240))
        img.draw_string(90, 110, "loading model...", color=(255, 255, 255), scale=2)
        lcd.display(img)

    uart = init_uart()
    comm = Comm(uart)

    try:
        task = None
        task = kpu.load(model_addr)
        kpu.init_yolo2(task, 0.5, 0.3, 5, anchors) # threshold:[0,1], nms_value: [0, 1]
        while(True):
            img = sensor.snapshot()
            t = time.ticks_ms()
            objects = kpu.run_yolo2(task, img)
            t = time.ticks_ms() - t
            if objects:
                for obj in objects:
                    pos = obj.rect()
                    img.draw_rectangle(pos)
                    img.draw_string(0, 2, "Welcome!" , scale=4, color=(255, 0, 0))
                lcd.display(img)
                comm.send_detect_result(objects, labels)
                Servo()
            lcd.display(img)
            LCD_Show()
    except Exception as e:
        raise e
    finally:
        if not task is None:
            kpu.deinit(task)


if __name__ == "__main__":
    try:
        #main(anchors = anchors, labels=labels, model_addr=0x300000, lcd_rotation=0)
        main(anchors = anchors, labels=labels, model_addr="/sd/model-149484.kmodel")
    except Exception as e:
        sys.print_exception(e)
        lcd_show_except(e)
    finally:
        gc.collect()
